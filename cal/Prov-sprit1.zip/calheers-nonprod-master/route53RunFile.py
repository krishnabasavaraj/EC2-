#!/usr/bin/python3

import os, yaml, sys

def generateYml():
	try:
		envFile = os.path.realpath(os.path.dirname(os.path.realpath('__file__')) + '/run.yml')
		with open(envFile) as f:
			envData = yaml.load(f, Loader=yaml.FullLoader)
		# print(envData)
		if envData is not None:
			if envData['type'] is None:
				return "No type items in run.yml, hence cannot create deploy.sh"
			else:
				if {"type"} <= envData.keys():
					deployFile = os.path.dirname(os.path.realpath('__file__')) + "/route53deploy.sh"
					#print(deployFile)
					typeName = envData["type"][0]
					with open(deployFile, "w") as fo:
						fo.write("#!/usr/bin/env sh -e\n\n")
						typesData = envData["type"]
						for typeData in typesData:
							typeData =  dict(typeData)
							typeName = list(typeData.keys())[0]
							# print(typeName)
							hostnames = []
							for items in typeData[typeName]:
								if list(items.keys())[0] == "hostnames":
									hostnames = items["hostnames"]
								for host in hostnames:
									if host is not None:
										hostFile = os.path.realpath(os.path.dirname(os.path.realpath('__file__')) + "/{typeName}/{host}.vars.yml".format(typeName=typeName, host=host))
										with open(hostFile) as f:
											hostData = yaml.load(f, Loader=yaml.FullLoader)	
										ip = hostData["ip"]
										fo.write("ansible-playbook route53.ansible.yml --extra-vars \"ip={ip} hostname={host}\"\n".format(typeName=typeName, host=host, ip=ip))
										fo.write("\n")
						fo.close()
					return "Created {deployFile} script file!!".format(deployFile=deployFile)
				else:
					req = {"type"}
					curr = envData.keys()
					missingParams = list((req^curr)&req)
					print("[ERROR] The below mandatory variables are missing in run.yml:")
					for item in missingParams:
						print(item)
					return ""
					
		else:
			return "No data found in run.yml, hence cannot create deploy.sh"
	except Exception as e:
		print(e)
		return "File not created!!"


if __name__ == "__main__":
	args = sys.argv
	if len(args) == 1:
		result = generateYml()
		print(result)
	else:
		print("Incorrect arguments passed\nUsage: python3 "+ os.path.basename(__file__))
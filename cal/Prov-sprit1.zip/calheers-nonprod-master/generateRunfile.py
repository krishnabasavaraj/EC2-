#!/usr/bin/python3

import os, yaml, sys

def generateYml():
	try:
		envFile = os.path.realpath(os.path.dirname(os.path.realpath('__file__')) + '/run.yml')
		with open(envFile) as f:
			envData = yaml.load(f, Loader=yaml.FullLoader)
		# print(envData)
		if envData is not None:
			if envData['type'] is None:
				return "No type items in run.yml, hence cannot create deploy.sh"
			else:
				if {"type"} <= envData.keys():
					# key = ""
					deployFile = os.path.dirname(os.path.realpath('__file__')) + "/deploy.sh"
					with open(deployFile, "w") as fo:
						fo.write("#!/usr/bin/env sh -e\n\n")
						typesData = envData["type"]
						for typeData in typesData:
							typeData =  dict(typeData)
							application = list(typeData.keys())[0]
							# print(application)
							services = []
							for service in typeData[application]:
								component =  dict(service)
								componentName = list(component.keys())[0]
								fo.write("aws cloudformation validate-template --template-body file://{application}/{serviceName}/{serviceName}.cf.yml\n".format(application=application, serviceName=componentName))
								# print(component)
								for host in component[componentName][0]["hostnames"]:
									fo.write("ansible-playbook {application}/{serviceName}/{serviceName}.ansible.yml --extra-vars \"@{application}/{serviceName}/{hostname}.vars.yml\" --extra-vars \"@nonprod.vars.yml\"\n".format(application=application, serviceName=componentName, hostname=host))
								fo.write("\n")
						fo.close()
				else:
					req = {"type"}
					curr = envData.keys()
					missingParams = list((req^curr)&req)
					print("[ERROR] The below mandatory variables are missing in run.yml:")
					for item in missingParams:
						print(item)
					return ""

		else:
			return "No data found in run.yml, hence cannot create deploy.sh"
	except Exception as e:
		print(e)
		return "File not created!!"


if __name__ == "__main__":
	args = sys.argv
	if len(args) == 1:
		generateYml()
	else:
		print("Incorrect arguments passed\nUsage: python3 "+ os.path.basename(__file__))
# EC2 Build Automation Pipeline

EC2 Build Automation Pipeline
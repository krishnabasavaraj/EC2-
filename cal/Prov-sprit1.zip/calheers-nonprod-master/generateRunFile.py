#!/usr/bin/python3

import os, yaml, sys

def generateYml():
	try:
		envFile = os.path.realpath(os.path.dirname(os.path.realpath('__file__')) + '/run.yml')
		with open(envFile) as f:
			envData = yaml.load(f, Loader=yaml.FullLoader)
		# print(envData)
		if envData is not None:
			if envData['type'] is None:
				return "No type items in run.yml, hence cannot create deploy.sh"
			else:
				if {"type"} <= envData.keys():
					# key = ""
					deployFile = os.path.dirname(os.path.realpath('__file__')) + "/deploy.sh"
					with open(deployFile, "w") as fo:
						fo.write("#!/usr/bin/env sh -e\n\n")
						typesData = envData["type"]
						for typeData in typesData:
							typeData =  dict(typeData)
							typeName = list(typeData.keys())[0]
							# print(typeName)
							fo.write("aws cloudformation validate-template --template-body file://{typeName}/{typeName}.cf.yml\n".format(typeName=typeName))
							hostnames = []
							for items in typeData[typeName]:
								if list(items.keys())[0] == "hostnames":
									hostnames = items["hostnames"]
								for host in hostnames:
									if host is not None:
										fo.write("ansible-playbook {typeName}/{typeName}.ansible.yml --extra-vars \"@{typeName}/{host}.vars.yml\"\n".format(typeName=typeName, host=host))
										fo.write("\n")
						fo.close()
				else:
					req = {"type", "hostnames"}
					curr = envData.keys()
					missingParams = list((req^curr)&req)
					print("[ERROR] The below mandatory variables are missing in run.yml:")
					for item in missingParams:
						print(item)
					return ""

		else:
			return "No data found in run.yml, hence cannot create deploy.sh"
	except Exception as e:
		print(e)
		return "File not created!!"


if __name__ == "__main__":
	args = sys.argv
	if len(args) == 1:
		generateYml()
	else:
		print("Incorrect arguments passed\nUsage: python3 "+ os.path.basename(__file__))

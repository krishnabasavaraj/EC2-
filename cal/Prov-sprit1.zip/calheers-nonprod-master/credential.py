#!/usr/bin/python3

import os, yaml, sys

def generateYml():
	envFile = os.path.realpath(os.path.dirname(os.path.realpath('__file__')) + '/run.yml')
	with open(envFile) as f:
		envData = yaml.load(f, Loader=yaml.FullLoader)
		# print(envData)
	if envData is not None:
		if envData['credential'] is None:
			return "No type items in run.yml"
		else:
			if {"credential"} <= envData.keys():
				typeName = envData["credential"][0]
				print(typeName)
	else:
		return "No data found in run.yml"

generateYml()
# if __name__ == "__main__":
# 	args = sys.argv
# 	if len(args) == 1:
# 		print("main")
# 		result = generateYml()
# 		print(result)
# 		if result == "OK":
# 			print(os.environ["type"])
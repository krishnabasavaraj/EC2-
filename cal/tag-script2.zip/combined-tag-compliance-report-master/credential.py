import os, yaml

def generateYml():
	envFile = os.path.realpath(os.path.dirname(os.path.realpath('__file__')) + '/run.yml')
	with open(envFile) as f:
		envData = yaml.load(f, Loader=yaml.FullLoader)
	if envData is not None:
		if envData['credential'] is None:
			print("No type items in run.yml")
		else:
			if {"credential"} <= envData.keys():
				typeName = envData["credential"]
				print(typeName)
	else:
		print("No data found in run.yml")


if __name__ == "__main__":
	generateYml()



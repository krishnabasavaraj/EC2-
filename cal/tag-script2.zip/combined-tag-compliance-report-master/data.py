from datetime import datetime
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
import pandas as pd
import os
from os.path import exists
import traceback


def Collect_Data(cdf: pd.DataFrame, isLastElement):
    path = os.getcwd() + "/tag-complaince.csv"
    print(f"\npath = {path}\n")
    file_exists = exists(path)
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', None)
    pd.set_option('display.max_colwidth', None)
    if not cdf.empty and file_exists:
        odf = pd.read_csv(os.getcwd() + "/tag-complaince.csv")
        ndf = pd.concat([odf, cdf], ignore_index=True)
        ndf.fillna("NA", inplace=True)
        ndf.to_csv("tag-complaince.csv", index=False)
    elif not cdf.empty and not file_exists:
        ndf = cdf
        ndf.fillna("NA", inplace=True)
        ndf.to_csv("tag-complaince.csv", index=False)
    file_exists = exists(path)
    if isLastElement == "true" and file_exists:
        mailDF = pd.read_csv(path)
        mailDF.fillna("NA", inplace=True)
        send_mail(mailDF.to_html())


def send_mail(FinalData):
    print("Send Email Function...")
    print(os.listdir(os.getcwd()))
    fpath = os.getcwd() + "/tag-complaince.csv"
    #receivers_mail = ['mmurshidum@deloitte.com', 'krishna.muthagouni@calheers.ca.gov', 'sumeet.a.lnu@calheers.ca.gov', 'asif.a.salam@calheers.ca.gov', 'sneha.k.kumar@calheers.ca.gov', 'malav.s.shah@calheers.ca.gov', 'm.a.murshidum@calheers.ca.gov', 's.s.shanmukkha@calheers.ca.gov', 'prasanth.mm@calheers.ca.gov', 'gummadi.a.amar@calheers.ca.gov']
    receivers_mail = ['allen.g.andrews@calheers.ca.gov','shivam.a.seth@calheers.ca.gov','rajat.j.jain@calheers.ca.gov','mmurshidum@deloitte.com', 'krishna.muthagouni@calheers.ca.gov', 'sumeet.a.lnu@calheers.ca.gov', 'asif.a.salam@calheers.ca.gov', 'malav.s.shah@calheers.ca.gov', 'm.a.murshidum@calheers.ca.gov', 'prasanth.mm@calheers.ca.gov', 'gummadi.a.amar@calheers.ca.gov','prajitha.nambiar@calheers.ca.gov']

    # Making Email Message
    message = MIMEMultipart()
    message['Subject'] = "[P2] Alert - Combined Tag Compliance report across all AWS Accounts"
    message['From'] = 'jenkins-master@calheers.net'
    message['To'] = ", ".join(receivers_mail)
    e = datetime.now()

    # Email message body
    body = f"""
    <html>
    <head></head>
    <body>
        <p>Hi Team, <p>
        <p>Please find the tag compliance report of {e.strftime("%a %b %d, %Y %H:%M:%S")} PST and take neccessary action.<p> 
        {FinalData}
        <p>Thanks</p>
    </body>
    </html>
    """
    body_content = body
    message.attach(MIMEText(body_content, "html"))

    # For attaching file
    with open(fpath, 'rb') as cfile:
        message.attach(MIMEApplication(cfile.read(), Name="tag-complaince.csv"))

    # Sending Email
    try:
        server = smtplib.SMTP('localhost')
        msg_body = message.as_string()
        server.sendmail(message['From'], receivers_mail, msg_body)
        server.close()
        print("Success::  Email Sent!!!! ")
    except Exception as e:
        print("Error for connection: {}".format(type(e).__name__))
        print(traceback.format_exc())

import boto3
import pandas as pd
import sys
from data import Collect_Data
import traceback


def generateTagComplianceData(access_key, secret_key, Account):
    try:
        session = boto3.Session(aws_access_key_id=access_key, aws_secret_access_key=secret_key)
        ec2 = session.resource('ec2', region_name='us-west-2')
        tag = ec2.Tag('resource_id', 'key', 'value')
        ec2Df = pd.DataFrame(columns=[
                             'ACCOUNT', 'INSTANCEID', 'INSTANCENAME', "MAIN TAG", "RTC CR", "SNOW CAB", "InitiativeTAG"])
        instances = None
        instances = ec2.instances.all()
        if instances is not None:
            for instance in instances:
                instanceName = "NA"
                maintagName = "NA"
                rtctag = "NA"
                snowtag = "NA"
                initag = "NA"
                for tag in instance.tags:
                    if tag['Key'] == 'Name':
                        instanceName = tag['Value'].strip()
                    if tag['Key'] == 'Main Tag':
                        maintagName = tag['Value'].strip()
                    if tag['Key'] == 'RTC CR':
                        rtctag = tag['Value'].strip()
                    if tag['Key'] == 'SNOW CAB':
                        snowtag = tag['Value'].strip()
                    if tag['Key'] == 'Initiative':
                        initag = tag['Value'].strip()

                if ((maintagName == "CR") and ((snowtag in ["NA", ""] and rtctag not in ["NA",""]) or (snowtag not in ["NA", ""] and rtctag in ["NA", ""]) or (snowtag in ["NA", ""] and rtctag in ["NA", ""]))) or (maintagName in  ["NA", ""]):
                    new_data = {'ACCOUNT': Account, 'INSTANCEID': instance.id, 'INSTANCENAME': instanceName, "MAIN TAG": maintagName, "RTC CR": rtctag, "SNOW CAB": snowtag, "InitiativeTAG": initag}
                    df_dictionary = pd.DataFrame([new_data])
                    ec2Df = pd.concat([ec2Df, df_dictionary], ignore_index=True)
            return ec2Df
        else:
            print(f"No instances found for this {Account}. ")
    except Exception as e:
        print(e)
        print(traceback.format_exc())





if __name__ == "__main__":
    access_key = sys.argv[1]
    secret_key = sys.argv[2]
    Account = sys.argv[3]
    isLastElement = sys.argv[4]
    print("Executing in Account :" + Account+"\n")
    account_data = generateTagComplianceData(access_key, secret_key, Account)
    if account_data is not None:
        Collect_Data(account_data, isLastElement)



